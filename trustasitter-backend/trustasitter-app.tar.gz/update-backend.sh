#!/bin/bash
echo "Updating TrustaSitter backend..."

cd /opt/TrustaSitter/backend || exit 1

# 拉取最新代码
sudo git reset --hard
sudo git pull origin main

# 安装/更新依赖
npm install

# 重启 PM2 服务，如果不存在就新建
pm2 restart trustasitter-backend || pm2 start index.js --name trustasitter-backend

echo "Update complete!"
exit 0
