#!/bin/bash
echo "Installing TrustaSitter backend..."

# 安装 Node.js 和 Git
sudo apt-get update -y
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs git

# 下载项目到 /opt
cd /opt
if [ ! -d "TrustaSitter" ]; then
    sudo git clone https://github.com/Bruno8006/TrustaSitter.git
else
    echo "TrustaSitter repo already exists, skipping clone"
fi

cd TrustaSitter/backend

# 安装依赖
npm install

# 安装并启动 PM2
sudo npm install -g pm2
pm2 start index.js --name trustasitter-backend
pm2 save
pm2 startup

echo "Installation complete!"
exit 0
