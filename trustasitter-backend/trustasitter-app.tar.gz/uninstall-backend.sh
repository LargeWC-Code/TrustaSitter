#!/bin/bash
echo "Uninstalling TrustaSitter backend..."

# 停止 PM2 服务
pm2 delete trustasitter-backend || true

# 删除项目文件
sudo rm -rf /opt/TrustaSitter

# 可选：卸载 Node.js，如果只为这个项目安装的话
# sudo apt-get remove -y nodejs npm
# sudo apt-get autoremove -y

echo "Uninstall complete!"
exit 0
